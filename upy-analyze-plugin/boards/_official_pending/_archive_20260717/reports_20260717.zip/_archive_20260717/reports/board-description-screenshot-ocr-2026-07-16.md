# 板卡描述截图 OCR 结果 - 2026-07-16

- 截图目录：`G:\MicroPython_Skills\upy-analyze-plugin\boards\_official_pending\板卡描述`
- 板卡目录数：34
- PNG 图片数：105
- OCR 有文本的板卡：27
- OCR 识别到型号的板卡：3

| official_slug | 图片数 | OCR 字符数 | 类型线索 | 型号线索 |
|---|---:|---:|---|---|
| `DVK_BL652` | 0 | 0 |  |  |
| `RPI_PICO2_W` | 0 | 0 |  |  |
| `SAMD_GENERIC_D21X18` | 0 | 0 |  |  |
| `SAMD_GENERIC_D51X19` | 0 | 0 |  |  |
| `SAMD_GENERIC_D51X20` | 0 | 0 |  |  |
| `UM_TINYPICO` | 0 | 0 |  |  |
| `VK_RA6M5` | 0 | 0 |  |  |
| `CYTRON_MOTION_2350_PRO` | 17 | 10946 | button, camera, display, imu, led, neopixel, storage |  |
| `GARATRONIC_NADHAT_F405` | 8 | 12769 | led, power_mgmt, storage |  |
| `GARATRONIC_PYBSTICK26_ESP32C3` | 2 | 3376 | imu, led |  |
| `GARATRONIC_PYBSTICK26_F411` | 4 | 7548 | imu, led |  |
| `GARATRONIC_PYBSTICK26_RP2040` | 4 | 7550 | imu, led |  |
| `MIMXRT1010_EVK` | 2 | 1318 | audio_codec, button, led, microphone | audio_codec: WM8960 |
| `MIMXRT1015_EVK` | 2 | 879 | audio_codec, microphone |  |
| `MIMXRT1020_EVK` | 2 | 1101 | audio_codec, ethernet, microphone, power_mgmt, storage |  |
| `MIMXRT1050_EVK` | 3 | 1403 | audio_codec, camera, display, ethernet, imu, microphone, power_mgmt, storage |  |
| `MIMXRT1060_EVK` | 3 | 1266 | audio_codec, camera, display, ethernet, imu, microphone, storage |  |
| `MIMXRT1064_EVK` | 2 | 1072 | audio_codec, camera, display, ethernet, microphone, storage |  |
| `MIMXRT1170_EVK` | 3 | 1663 | audio_codec, camera, display, ethernet, microphone, storage |  |
| `PCA10000` | 1 | 1026 | button, led, neopixel |  |
| `PCA10001` | 1 | 1547 | battery_connector, button, camera, led |  |
| `PCA10028` | 1 | 1484 | battery_connector, button, camera, led |  |
| `PCA10031` | 1 | 1006 | button, led, neopixel |  |
| `PCA10056` | 3 | 5616 | battery_connector, button, camera, ethernet, imu, led |  |
| `PCA10059` | 3 | 5982 | button, ethernet, imu, led, neopixel |  |
| `PCA10090` | 4 | 4924 | button, led |  |
| `RPI_PICO2` | 7 | 4528 | ethernet, led |  |
| `SAMD21_XPLAINED_PRO` | 2 | 1752 | button, display, led |  |
| `STM32H747I_DISCO` | 2 | 2423 | audio_codec, button, camera, display, ethernet, led, microphone, storage, touch |  |
| `UM_FEATHERS3NEO` | 7 | 4531 | battery_connector, imu, led, neopixel, power_mgmt |  |
| `W5100S_EVB_PICO` | 8 | 7229 | camera, ethernet, imu, led, storage | ethernet: W5100S |
| `W5500_EVB_PICO` | 7 | 6242 | ethernet, imu, led, storage | ethernet: W5500 |
| `WIPY` | 4 | 3089 | button, ethernet, led, neopixel |  |
| `WT51822_S4AT` | 2 | 430 | led |  |
