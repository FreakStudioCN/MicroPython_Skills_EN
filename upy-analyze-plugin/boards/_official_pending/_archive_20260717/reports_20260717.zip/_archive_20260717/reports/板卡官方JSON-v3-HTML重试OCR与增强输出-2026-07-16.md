# 板卡官方 JSON v3 HTML 重试、OCR 与增强输出

日期：2026-07-16

## 本轮执行

1. 检查 `MicroPython_Learn` 环境：
   - `pytesseract`、`PIL`、`bs4`、`lxml` 可用。
   - `tesseract.exe` 初始可找到但不能执行，退出码 `3221225781`。
   - 诊断后确认缺少 `libcurl.dll`，同时补了 `libstdcxx`。
   - 修复后最小 OCR 测试通过：`tesseract 5.5.2`，能识别测试图中文字。

2. 重新尝试抓取失败厂商 HTML：
   - 将抓取请求头改成浏览器式 `User-Agent` / `Accept` / `Accept-Language`。
   - 使用 `MicroPython_Learn` 运行完整审计脚本并启用 `--refresh-html`。
   - 审计脚本：`G:\blockless-plugin-course(1)\scripts\audit_board_json_with_vendor_html_and_pinout_images_v2_20260715.py`

3. 重新执行 pinout 图片 OCR：
   - OCR 成功运行在 199 个本地 pinout 图片资源上。
   - PDF/SVG/外部 source URL 等仍不按位图 OCR。

4. 生成增强 JSON：
   - 原 v3 目录未覆盖。
   - 新增强目录：`G:\blockless-plugin-course(1)\_tmp_official_board_json_v3_html_ocr_enriched_20260716_r2`
   - 增强脚本：`G:\blockless-plugin-course(1)\scripts\enrich_official_board_jsons_from_html_ocr_audit_20260716.py`
   - 增强报告：`G:\blockless-plugin-course(1)\official-board-json-v3-html-ocr-enrichment-report-2026-07-16-r2.md`

## HTML 重试结果

- 失败页面明细清单：`G:\blockless-plugin-course(1)\厂商HTML失败页面清单-2026-07-16.md`
- 成功 fetched：153
- 仍 `http_403`：14
- 仍 `URLError`：6
- 仍 `TimeoutError`：2
- 仍 `missing/404`：11
- 仍 `http_500`：1
- `not_html_url`：1
- `not_url`：34

和上轮相比：

- HTML 成功数从 149 提升到 153。
- 403 从 20 降到 14。
- 仍失败的真实 URL 主要集中在 Microchip、Nordic、NXP、部分 ST、mchobby/Garatronic、Raspberry Pi 等站点。
- `not_url` 多数是 CSV 中厂商 HTML 字段为 `无`，后续只能依赖 MicroPython source、GitHub source、CSV 图片/source 字段或人工补产品页。

## OCR 结果

- `ocr_available`: true
- `ocr_status=tesseract`: 199
- `ocr_status=not_run`: 9

OCR 从图片中额外识别到的主要类型线索：

- `ethernet`: 14
- `neopixel`: 14
- `power_mgmt`: 12
- `storage`: 8
- `button`: 8
- `display`: 6
- `imu`: 5
- `led`: 5
- `battery_connector`: 5
- `radio_lora`: 2
- `camera`: 2

OCR/HTML 识别到的型号线索包括：

- `WS2812`
- `SSD1306`
- `APA102`
- `W5100S`
- `W5500`
- 以及审计报告中原有的 `MP34DT05`、`LAN8720`、`LSM6DSOX`、`MCP73831`、`MAX17048` 等。

## 增强 JSON 规则

本轮不是只补 15 个高置信型号，而是分层补：

- 明确型号且同类没有 source 既有型号：写入 `onboard_peripherals`。
- 普通类型命中：写入 `onboard_peripherals` 的弱候选条目。
- 同类已有 source 解析型号但 HTML/OCR 给出不同型号：不直接写成真实外设，放入 `source_evidence.html_pinout_ocr_audit_20260716.model_conflict_candidates`。
- 所有新增候选都使用：
  - `occupied_pins: {}`
  - `always_used: false`
  - `pin_evidence: "needs_pin_mapping"`
  - 未确认型号的类型候选使用 `verification: "needs_model_and_pin_mapping"`
  - 明确型号但未确认引脚使用 `verification: "needs_pin_mapping"`

这样不会把未确认的 HTML/OCR 线索变成 select-hw 的硬 GPIO 冲突。

## 增强输出统计

- 输出 JSON：222
- JSON 解析错误：0
- `upy-select-hw-plugin/scripts/select_hw_manifest.py::load_board_definition` 加载：222/222，错误 0
- 有增强候选的板卡：87
- 直接新增型号候选：13
- 新增类型候选：245
- 因 source 既有型号不同而延后复核的型号候选：11

示例：

- `ARDUINO_NANO_33_BLE_SENSE`
  - 新增 `microphone MP34DT05`
  - `APDS-9960`、`LPS22HB`、`BMM150`、`LSM9DS1` 因同类型已有 source 型号，放入 conflict candidates。
  - 新增 `camera` 弱候选，需人工确认。
- `LILYGO_T3_S3`
  - HTML/OCR 给出 `SX1276`，但 source 已有 `SX1262`，所以不直接新增 LoRa 外设，放入 conflict candidates。
  - 新增 `imu` 弱候选，需人工确认。
- `SPARKFUN_XRP_CONTROLLER`
  - 新增 `imu LSM6DSOX`，引脚待确认。
- `OLIMEX_ESP32_EVB`
  - 新增 `ethernet LAN8720`，引脚待确认。
  - 新增 `button/display/led` 弱候选。

## 仍需后续处理

- 仍失败 HTML 的真实 URL 需要替代源或人工访问补充。
- 弱候选条目需要人工或更严格规则二次清洗，尤其是 `camera/display/imu` 这类容易来自页面配件/生态文案的关键词。
- PDF/SVG pinout 还需要后续转换为位图或单独解析。
- r2 输出已继续叠加 `板卡描述` 截图 OCR，生成 r3，并已发布到正式 `G:\MicroPython_Skills\upy-analyze-plugin\boards`。

## 截图 OCR 与正式发布

- 截图 OCR 输入目录：`G:\MicroPython_Skills\upy-analyze-plugin\boards\_official_pending\板卡描述`
- 截图 OCR 结果：`G:\blockless-plugin-course(1)\board-description-screenshot-ocr-2026-07-16.md`
- 截图 OCR JSON：`G:\blockless-plugin-course(1)\board-description-screenshot-ocr-2026-07-16.json`
- r3 临时 JSON：`G:\blockless-plugin-course(1)\_tmp_official_board_json_v3_html_ocr_enriched_20260716_r3`
- r3 截图 OCR 增强报告：`G:\blockless-plugin-course(1)\official-board-json-v3-description-screenshot-ocr-enrichment-report-2026-07-16.md`
- 正式发布报告：`G:\blockless-plugin-course(1)\official-board-json-formal-publish-report-2026-07-16.md`
- 旧正式 JSON 备份：`G:\blockless-plugin-course(1)\_backup_formal_board_jsons_before_v3_html_ocr_20260716\20260716-233900`

截图 OCR 覆盖：

- 板卡描述子目录：34
- PNG 截图：105
- OCR 有文本的板卡：27
- 截图 OCR 额外增强板卡：26
- 截图 OCR 新增弱类型候选：53
- 截图 OCR 新增明确型号候选：0

正式发布：

- 正式目录：`G:\MicroPython_Skills\upy-analyze-plugin\boards`
- 覆盖官方板卡 JSON：222
- 正式目录 JSON 总数：231
- 正式目录 JSON 解析错误：0
- 官方 222 个 JSON schema：`blockless.micropython.skill_board_definition.official_source_import.v3`
- `select_hw_manifest.load_board_definition()` 加载正式目录官方板卡：222/222，错误 0
- `G:\MicroPython_Skills\upy-select-hw-plugin\test\smoke_tests.py`：全部通过
